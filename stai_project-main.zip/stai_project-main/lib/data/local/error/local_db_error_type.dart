enum LocalDBErrorType {
  alreadyExist,
  notExist,
  unknown,
}
