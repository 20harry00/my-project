import 'package:fast_app_base/common/theme/color/abs_theme_colors.dart';

class LightAppColors extends AbstractThemeColors {
  const LightAppColors();
}
