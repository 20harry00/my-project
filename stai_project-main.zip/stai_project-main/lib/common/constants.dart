export 'theme/color/abs_theme_colors.dart';
export 'theme/shadows/abs_theme_shadows.dart';

const basePath = 'assets/image';
