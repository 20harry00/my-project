package com.example.fast_app_base

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
